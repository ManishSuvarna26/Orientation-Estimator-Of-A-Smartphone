function showIP()
% SHOWIP Show IP of connected network interfaces

  import('com.liu.sensordata.*');
  StreamSensorDataReader.showIPs();
end
